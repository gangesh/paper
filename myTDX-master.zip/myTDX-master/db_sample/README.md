This folder is not used per se. You may want to use the config.php and todolist.db files
to start with, by copying them into your own db/ folder. They are configured for sqlite,
and the entries contain a few informative tips.
